/*
 FXNESS FRONTEND
 This file is the browser-side interface. It does NOT create fake balances,
 fake deposits or fake trades.

 Connect these secure backend endpoints:
 POST /api/auth/login
 POST /api/auth/register
 POST /api/auth/logout
 GET  /api/account
 GET  /api/markets
 GET  /api/trades
 GET  /api/trades/history
 GET  /api/transactions
 POST /api/orders
 POST /api/orders/:id/close
 POST /api/deposits/mpesa
 POST /api/withdrawals
 PATCH /api/profile

 NEVER put broker, M-Pesa, database or other secret credentials here.
*/

const API_BASE = "https://YOUR-BACKEND-DOMAIN.com/api";

const state = {
  token: sessionStorage.getItem("fxness_token") || "",
  account: null,
  markets: [],
  side: "buy",
  preview: false
};

const $ = id => document.getElementById(id);
const $$ = selector => document.querySelectorAll(selector);

document.addEventListener("DOMContentLoaded", init);

function init() {
  bindNavigation();
  bindAuth();
  bindForms();
  bindTradingControls();
  bindRefreshButtons();
  if (state.token) {
    showApp();
    loadAccount();
  } else {
    showAuth("login");
  }
}

function bindNavigation() {
  document.addEventListener("click", event => {
    const auth = event.target.closest("[data-auth]");
    if (auth) return showAuth(auth.dataset.auth);

    const page = event.target.closest("[data-page]");
    if (page) showPage(page.dataset.page);
  });
}

function bindAuth() {
  $("previewButton").addEventListener("click", startPreview);
  $("exitPreview").addEventListener("click", exitPreview);
  $("logoutButton").addEventListener("click", logout);

  $("loginForm").addEventListener("submit", async e => {
    e.preventDefault();
    clearMessage("loginMessage");
    try {
      const result = await apiRequest("/auth/login", {
        method: "POST",
        body: {
          email: $("loginEmail").value.trim(),
          password: $("loginPassword").value
        }
      });
      if (!result.token) throw new Error("Login response did not contain an authentication token.");
      state.token = result.token;
      sessionStorage.setItem("fxness_token", result.token);
      showApp();
      await loadAccount();
      showToast("Signed in successfully.");
    } catch (error) {
      setMessage("loginMessage", error.message, true);
    }
  });

  $("registerForm").addEventListener("submit", async e => {
    e.preventDefault();
    clearMessage("registerMessage");

    const name = $("registerName").value.trim();
    const email = $("registerEmail").value.trim();
    const password = $("registerPassword").value;
    const confirm = $("registerConfirm").value;

    if (password !== confirm) {
      setMessage("registerMessage", "Passwords do not match.", true);
      return;
    }

    try {
      const result = await apiRequest("/auth/register", {
        method: "POST",
        body: { name, email, password }
      });

      if (result.token) {
        state.token = result.token;
        sessionStorage.setItem("fxness_token", result.token);
        showApp();
        await loadAccount();
      } else {
        showAuth("login");
        setMessage("loginMessage", "Account created. Please sign in.", false);
      }
    } catch (error) {
      setMessage("registerMessage", error.message, true);
    }
  });
}

function bindForms() {
  $("depositForm").addEventListener("submit", async e => {
    e.preventDefault();
    clearMessage("depositMessage");

    if (state.preview) {
      setMessage("depositMessage", "Preview mode: no real payment was initiated.", true);
      return;
    }

    try {
      const result = await apiRequest("/deposits/mpesa", {
        method: "POST",
        body: {
          phone: $("depositPhone").value.trim(),
          amount: Number($("depositAmount").value)
        }
      });
      setMessage("depositMessage", result.message || "Deposit request submitted.", false);
      showToast("Deposit request submitted.");
      await loadTransactions();
      await loadAccount();
    } catch (error) {
      setMessage("depositMessage", error.message, true);
    }
  });

  $("withdrawForm").addEventListener("submit", async e => {
    e.preventDefault();
    clearMessage("withdrawMessage");

    if (state.preview) {
      setMessage("withdrawMessage", "Preview mode: no real withdrawal was initiated.", true);
      return;
    }

    try {
      const result = await apiRequest("/withdrawals", {
        method: "POST",
        body: {
          method: $("withdrawMethod").value,
          phone: $("withdrawPhone").value.trim(),
          amount: Number($("withdrawAmount").value)
        }
      });
      setMessage("withdrawMessage", result.message || "Withdrawal request submitted.", false);
      showToast("Withdrawal request submitted.");
      await loadTransactions();
      await loadAccount();
    } catch (error) {
      setMessage("withdrawMessage", error.message, true);
    }
  });

  $("profileForm").addEventListener("submit", async e => {
    e.preventDefault();
    clearMessage("profileMessage");

    if (state.preview) {
      setMessage("profileMessage", "Preview mode: profile changes are not saved.", true);
      return;
    }

    try {
      const result = await apiRequest("/profile", {
        method: "PATCH",
        body: {
          name: $("profileName").value.trim(),
          phone: $("profilePhone").value.trim()
        }
      });
      state.account = result.account || result;
      renderAccount();
      setMessage("profileMessage", "Profile updated.", false);
      showToast("Profile updated.");
    } catch (error) {
      setMessage("profileMessage", error.message, true);
    }
  });
}

function bindTradingControls() {
  $$(".trade-tab").forEach(button => {
    button.addEventListener("click", () => {
      $$(".trade-tab").forEach(b => b.classList.remove("active"));
      button.classList.add("active");
      state.side = button.dataset.side;
    });
  });

  $("tradeSymbol").addEventListener("change", updateSelectedQuote);
  $("tradeType").addEventListener("change", () => {
    $("tradePrice").required = $("tradeType").value !== "market";
  });

  $("tradeForm").addEventListener("submit", async e => {
    e.preventDefault();
    clearMessage("tradeMessage");

    if (state.preview) {
      setMessage("tradeMessage", "Preview mode: no real order was placed.", true);
      return;
    }

    const symbol = $("tradeSymbol").value;
    const type = $("tradeType").value;
    const volume = Number($("tradeVolume").value);
    const price = Number($("tradePrice").value) || null;
    const stopLoss = Number($("stopLoss").value) || null;
    const takeProfit = Number($("takeProfit").value) || null;

    if (!symbol || !volume) {
      setMessage("tradeMessage", "Select an instrument and enter a valid volume.", true);
      return;
    }

    if (type !== "market" && !price) {
      setMessage("tradeMessage", "A price is required for this order type.", true);
      return;
    }

    try {
      const result = await apiRequest("/orders", {
        method: "POST",
        body: { symbol, side: state.side, type, volume, price, stopLoss, takeProfit }
      });
      setMessage("tradeMessage", result.message || "Order submitted.", false);
      showToast("Order submitted.");
      $("tradeForm").reset();
      await loadAccount();
      await loadOpenTrades();
      await loadHistory();
    } catch (error) {
      setMessage("tradeMessage", error.message, true);
    }
  });
}

function bindRefreshButtons() {
  $("refreshMarkets").addEventListener("click", loadMarkets);
  $("refreshTrades").addEventListener("click", loadOpenTrades);
  $("refreshHistory").addEventListener("click", loadHistory);
  $("refreshTransactions").addEventListener("click", loadTransactions);
}

function showAuth(screen) {
  $("loginScreen").classList.toggle("hidden", screen !== "login");
  $("registerScreen").classList.toggle("hidden", screen !== "register");
  $("mainApp").classList.add("hidden");
}

function showApp() {
  $("loginScreen").classList.add("hidden");
  $("registerScreen").classList.add("hidden");
  $("mainApp").classList.remove("hidden");
  if (!state.preview) $("previewBanner").classList.add("hidden");
  showPage("dashboard");
}

function showPage(page) {
  $$(".page").forEach(p => p.classList.remove("active"));
  const target = $(`${page}Page`);
  if (target) target.classList.add("active");

  $$(".nav-item").forEach(item => {
    item.classList.toggle("active", item.dataset.page === page);
  });

  if (!state.preview) {
    if (page === "dashboard") loadDashboard();
    if (page === "markets") loadMarkets();
    if (page === "openTrades") loadOpenTrades();
    if (page === "history") loadHistory();
    if (page === "wallet") loadTransactions();
    if (page === "profile") renderAccount();
  }
}

function startPreview() {
  state.preview = true;
  state.account = {
    name: "Preview account",
    email: "preview@fxness.local",
    phone: "",
    balance: 0,
    equity: 0,
    marginUsed: 0,
    openTrades: 0,
    currency: "USD"
  };
  showApp();
  $("previewBanner").classList.remove("hidden");
  renderAccount();
  showToast("Preview mode enabled.");
}

function exitPreview() {
  state.preview = false;
  $("previewBanner").classList.add("hidden");
  showAuth("login");
}

async function logout() {
  try {
    if (state.token) await apiRequest("/auth/logout", { method: "POST" });
  } catch (_) {}
  state.token = "";
  state.account = null;
  sessionStorage.removeItem("fxness_token");
  showAuth("login");
}

async function loadDashboard() {
  await Promise.all([loadAccount(), loadMarkets(), loadTransactions()]);
}

async function loadAccount() {
  if (state.preview) return renderAccount();
  try {
    state.account = await apiRequest("/account");
    renderAccount();
  } catch (error) {
    if (/unauthorized|401|token/i.test(error.message)) logout();
  }
}

function renderAccount() {
  const a = state.account || {};
  $("balanceValue").textContent = formatMoney(a.balance || 0);
  $("equityValue").textContent = formatMoney(a.equity || 0);
  $("marginValue").textContent = formatMoney(a.marginUsed || a.margin_used || 0);
  $("openTradesValue").textContent = String(a.openTrades || a.open_trades || 0);
  $("balanceCurrency").textContent = a.currency || "USD";
  $("topUserName").textContent = a.name || "Account";
  $("profileName").value = a.name || "";
  $("profileEmail").value = a.email || "";
  $("profilePhone").value = a.phone || "";
}

async function loadMarkets() {
  if (state.preview) return renderMarkets([]);
  try {
    const result = await apiRequest("/markets");
    state.markets = Array.isArray(result) ? result : (result.markets || []);
    renderMarkets(state.markets);
  } catch (_) {
    renderMarkets([]);
    showToast("Market data is not connected.");
  }
}

function renderMarkets(markets) {
  const dashboard = $("dashboardMarkets");
  const table = $("marketsTable");

  if (!markets.length) {
    dashboard.innerHTML = '<div class="empty-state">No live market data connected.</div>';
    table.innerHTML = '<tr><td colspan="5" class="table-empty">No live market data connected.</td></tr>';
    return;
  }

  dashboard.innerHTML = markets.slice(0, 5).map(m => `
    <button class="market-row" data-symbol="${esc(m.symbol || "")}">
      <span><strong>${esc(m.symbol || "—")}</strong><small>${esc(m.name || "")}</small></span>
      <span>${formatPrice(m.bid)} / ${formatPrice(m.ask)}</span>
    </button>`).join("");

  table.innerHTML = markets.map(m => {
    const bid = Number(m.bid), ask = Number(m.ask);
    const spread = Number.isFinite(bid) && Number.isFinite(ask) ? (ask - bid).toFixed(5) : "—";
    return `<tr><td><strong>${esc(m.symbol || "—")}</strong></td><td>${formatPrice(m.bid)}</td><td>${formatPrice(m.ask)}</td><td>${spread}</td><td><button class="small-btn" data-trade-symbol="${esc(m.symbol || "")}">Trade</button></td></tr>`;
  }).join("");

  $$("[data-trade-symbol]").forEach(b => b.addEventListener("click", () => {
    $("tradeSymbol").value = b.dataset.tradeSymbol;
    updateSelectedQuote();
    showPage("trade");
  }));

  $$(".market-row").forEach(b => b.addEventListener("click", () => {
    $("tradeSymbol").value = b.dataset.symbol;
    updateSelectedQuote();
    showPage("trade");
  }));
}

function updateSelectedQuote() {
  const symbol = $("tradeSymbol").value;
  const m = state.markets.find(x => x.symbol === symbol);
  $("selectedInstrument").textContent = symbol || "—";
  $("selectedQuote").textContent = m ? `${formatPrice(m.bid)} / ${formatPrice(m.ask)}` : "—";
}

async function loadOpenTrades() {
  if (state.preview) return renderOpenTrades([]);
  try {
    const result = await apiRequest("/trades");
    renderOpenTrades(Array.isArray(result) ? result : (result.trades || []));
  } catch (_) {
    renderOpenTrades([]);
  }
}

function renderOpenTrades(trades) {
  const table = $("openTradesTable");
  if (!trades.length) {
    table.innerHTML = '<tr><td colspan="7" class="table-empty">No open trades available.</td></tr>';
    return;
  }

  table.innerHTML = trades.map(t => `
    <tr>
      <td>${esc(t.symbol || "—")}</td>
      <td><span class="side ${t.side === "sell" ? "sell" : "buy"}">${esc(t.side || "—")}</span></td>
      <td>${esc(t.volume ?? "—")}</td>
      <td>${formatPrice(t.entryPrice ?? t.entry_price)}</td>
      <td>${formatPrice(t.currentPrice ?? t.current_price)}</td>
      <td>${formatMoney(t.profit ?? t.pnl ?? 0)}</td>
      <td><button class="small-btn danger" data-close-trade="${esc(t.id || "")}">Close</button></td>
    </tr>`).join("");

  $$("[data-close-trade]").forEach(b => b.addEventListener("click", () => closeTrade(b.dataset.closeTrade)));
}

async function closeTrade(id) {
  if (!id || state.preview || !confirm("Close this position?")) return;
  try {
    await apiRequest(`/orders/${encodeURIComponent(id)}/close`, { method: "POST" });
    showToast("Position close request submitted.");
    await loadAccount();
    await loadOpenTrades();
    await loadHistory();
  } catch (error) {
    showToast(error.message);
  }
}

async function loadHistory() {
  if (state.preview) return renderHistory([]);
  try {
    const result = await apiRequest("/trades/history");
    renderHistory(Array.isArray(result) ? result : (result.trades || []));
  } catch (_) {
    renderHistory([]);
  }
}

function renderHistory(trades) {
  const table = $("historyTable");
  if (!trades.length) {
    table.innerHTML = '<tr><td colspan="7" class="table-empty">No trade history available.</td></tr>';
    return;
  }
  table.innerHTML = trades.map(t => `
    <tr><td>${formatDate(t.closedAt || t.closed_at || t.date)}</td><td>${esc(t.symbol || "—")}</td><td><span class="side ${t.side === "sell" ? "sell" : "buy"}">${esc(t.side || "—")}</span></td><td>${esc(t.volume ?? "—")}</td><td>${formatPrice(t.entryPrice ?? t.entry_price)}</td><td>${formatPrice(t.exitPrice ?? t.exit_price)}</td><td>${formatMoney(t.profit ?? t.pnl ?? 0)}</td></tr>`).join("");
}

async function loadTransactions() {
  if (state.preview) return renderTransactions([]);
  try {
    const result = await apiRequest("/transactions");
    const items = Array.isArray(result) ? result : (result.transactions || []);
    renderTransactions(items);
    renderActivity(items);
  } catch (_) {
    renderTransactions([]);
    renderActivity([]);
  }
}

function renderTransactions(items) {
  const table = $("transactionsTable");
  if (!items.length) {
    table.innerHTML = '<tr><td colspan="5" class="table-empty">No transactions available.</td></tr>';
    return;
  }
  table.innerHTML = items.map(x => `
    <tr><td>${formatDate(x.createdAt || x.created_at || x.date)}</td><td>${esc(x.type || "—")}</td><td>${esc(x.reference || "—")}</td><td>${formatMoney(x.amount || 0)}</td><td><span class="status ${String(x.status || "").toLowerCase()}">${esc(x.status || "—")}</span></td></tr>`).join("");
}

function renderActivity(items) {
  const box = $("dashboardActivity");
  if (!items.length) {
    box.innerHTML = '<div class="empty-state">No account activity available.</div>';
    return;
  }
  box.innerHTML = items.slice(0, 5).map(x => `
    <div class="activity-row"><div><strong>${esc(x.type || "Transaction")}</strong><small>${formatDate(x.createdAt || x.created_at || x.date)}</small></div><strong>${formatMoney(x.amount || 0)}</strong></div>`).join("");
}

async function apiRequest(path, options = {}) {
  if (API_BASE.includes("YOUR-BACKEND-DOMAIN")) {
    throw new Error("Backend not connected. Replace API_BASE in script.js with your secure backend URL.");
  }

  const headers = { "Content-Type": "application/json", ...(options.headers || {}) };
  if (state.token) headers.Authorization = `Bearer ${state.token}`;

  const response = await fetch(`${API_BASE}${path}`, {
    method: options.method || "GET",
    headers,
    body: options.body ? JSON.stringify(options.body) : undefined
  });

  let data = {};
  try { data = await response.json(); } catch (_) {}
  if (!response.ok) throw new Error(data.message || data.error || `Request failed (${response.status}).`);
  return data;
}

function setMessage(id, text, error) {
  const el = $(id);
  el.textContent = text;
  el.className = `form-message ${error ? "error" : "success"}`;
}

function clearMessage(id) {
  $(id).textContent = "";
  $(id).className = "form-message";
}

function showToast(message) {
  const toast = $("toast");
  toast.textContent = message;
  toast.classList.remove("hidden");
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.add("hidden"), 3500);
}

function formatMoney(value) {
  const n = Number(value);
  return Number.isFinite(n) ? n.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2}) : "0.00";
}

function formatPrice(value) {
  const n = Number(value);
  return Number.isFinite(n) ? n.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 5}) : "—";
}

function formatDate(value) {
  if (!value) return "—";
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? String(value) : d.toLocaleString();
}

function esc(value) {
  return String(value).replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#039;");
}
